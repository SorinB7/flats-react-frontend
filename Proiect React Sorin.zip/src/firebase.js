import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBf3dQuFT-OL4zN-Sy5h43qsUudXAA210o",
  authDomain: "flatfinder-533bc.firebaseapp.com",
  projectId: "flatfinder-533bc",
  storageBucket: "flatfinder-533bc.firebasestorage.app",
  messagingSenderId: "787807954945",
  appId: "1:787807954945:web:c75d42a1578e0e7433f800"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

const Spinner = () => {
    return (
      <div style={{ display: "flex", justifyContent: "center", marginTop: "20px" }}>
        <div className="loader"></div>
      </div>
    );
  };
  
  export default Spinner;
  